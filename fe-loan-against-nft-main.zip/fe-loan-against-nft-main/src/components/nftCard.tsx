import React from "react";

interface INftCard {
  title: string;
  address: string;
  description?: string;
  tokenId?: string;
  imgUrl?: string;
}
export function NftCard({
  title,
  address,
  description,
  tokenId,
  imgUrl,
}: INftCard) {
  return (
    <div className="py-2 px-4 border border-dark-200 flex justify-start items-center hover:bg-purple-200 hover:cursor-pointer">
      <div className="w-12 h-12">
        <img src={imgUrl} />
      </div>
      <div className="font-bold">#{tokenId}</div>
      <div className="ml-4 w-48">
        <div className="font-bold">{title}</div>
        <div className="text-xs text-gray-400 overflow-hidden">{address}</div>
      </div>
      <div className="ml-4 text-sm w-60 overflow-ellipsis">{description}</div>
    </div>
  );
}
