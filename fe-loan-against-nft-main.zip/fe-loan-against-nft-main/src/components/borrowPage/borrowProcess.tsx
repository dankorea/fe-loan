import React, { useEffect, useState } from "react";
import { TLoan } from "./offer";
import { ImCheckmark, ImCheckmark2, ImSpinner8 } from "react-icons/im";
import { approve, getApprovedFor } from "../../serivice/nftContract";
import {
  getLoanTokenAddress,
  setOffers,
  getEscrowContractAddress,
  requestLoan,
} from "../../serivice/escrowContract";

enum ApproveState {
  loading,
  approved,
  approving,
  notApproved,
}

interface IIconApprove {
  state: ApproveState;
}
function IconApprove({ state }: IIconApprove) {
  switch (state) {
    case ApproveState.loading:
      return (
        <span className="animate-spin">
          <ImSpinner8 />
        </span>
      );
    case ApproveState.approving:
      return (
        <span className="animate-spin">
          <ImSpinner8 />
        </span>
      );
    case ApproveState.approved:
      return (
        <span className="text-green-600">
          <ImCheckmark />
        </span>
      );
    case ApproveState.notApproved:
      return (
        <span className="text-gray-200">
          <ImCheckmark2 />
        </span>
      );
  }
}

interface IBorrowProcess {
  nft: any;
  loan: undefined | TLoan;
  nextStage: any;
}
function BorrowProcess({ nft, loan, nextStage }: IBorrowProcess) {
  const [isApproved, setIsApproved] = useState<ApproveState>(
    ApproveState.approving
  );
  const [isBorrowing, setIsBorrowing] = useState(false);

  useEffect(() => {
    async function initNFt() {
      const approval = await getApprovedFor(
        nft.contract.address,
        nft.tokenId,
        getEscrowContractAddress()
      );
      if (approval === true) {
        setIsApproved(ApproveState.approved);
      }
      if (approval === false) {
        setIsApproved(ApproveState.notApproved);
      }
      console.log("approve:", approval);
    }
    setIsApproved(ApproveState.loading);
    initNFt();
  }, [nft]);

  async function approveOnClicked() {
    console.log("start approve");
    try {
      setIsApproved(ApproveState.approving);
      const tx = await approve(
        nft.contract.address,
        getEscrowContractAddress(),
        nft.tokenId
      );
      await tx?.wait();
      setIsApproved(ApproveState.approved);
    } catch (e) {
      setIsApproved(ApproveState.notApproved);
      console.log("approve error", e);
    }
  }

  async function borrowOnClick() {
    console.log("start borrow");
    try {
      setIsBorrowing(true);
      const loan_token_address = await getLoanTokenAddress();
      if (!loan) {
        throw "no loan params";
      }
      const tx1 = await setOffers(
        nft.contract.address,
        nft.tokenId,
        loan?.amount,
        loan?.period,
        loan?.interest
      );
      await tx1.wait();
      const tx2 = await requestLoan(
        loan_token_address,
        nft.contract.address,
        nft.tokenId
      );
      await tx2.wait();
      setIsBorrowing(false);
      nextStage();
    } catch (e) {
      setIsBorrowing(false);
      console.log("borrow error", e);
    }
  }

  return (
    <div>
      <div className="mt-8">
        <div className="underline-gray-700 flex justify-between items-center">
          <span>1.Approve NFT</span>
          <IconApprove state={isApproved} />
        </div>
        <div className="text-sm text-gray-400">
          We will ask you approval to access your NFT. This is a one-time only
          operation.
        </div>
        <div className={isApproved === ApproveState.approved ? "hidden" : ""}>
          <button
            className="inline-flex justify-center items-center rounded-md border border-transparent bg-green-600
             px-4 py-2 text-sm font-medium text-green-100 hover:bg-blue-200 focus:outline-none focus-visible:ring-2
              focus-visible:ring-blue-500 focus-visible:ring-offset-2 disabled:bg-gray-400 disabled:text-gray-700"
            disabled={
              isApproved === ApproveState.loading ||
              isApproved === ApproveState.approving
            }
            onClick={approveOnClicked}
          >
            {isApproved === ApproveState.approving && (
              <span className="animate-spin mr-2">
                <ImSpinner8 />
              </span>
            )}
            <span>Approve</span>
          </button>
        </div>
      </div>
      <div className="mt-8">
        <div className="underline-gray-700 flex justify-between items-center">
          <span>2.Confirm Borrowing</span>
        </div>
        <div className="text-sm text-gray-400">Confirm and transfer</div>
        <div className={isApproved !== ApproveState.approved ? "hidden" : ""}>
          <button
            className="inline-flex justify-center items-center rounded-md border border-transparent bg-green-600
             px-4 py-2 text-sm font-medium text-green-100 hover:bg-blue-200 focus:outline-none focus-visible:ring-2
              focus-visible:ring-blue-500 focus-visible:ring-offset-2 disabled:bg-gray-400 disabled:text-gray-700"
            disabled={isBorrowing}
            onClick={borrowOnClick}
          >
            {isBorrowing && (
              <span className="animate-spin mr-2">
                <ImSpinner8 />
              </span>
            )}
            <span>Borrow</span>
          </button>
        </div>
      </div>
    </div>
  );
}

export { BorrowProcess };
