import React, { useEffect, useState } from "react";
import { ImCheckmark } from "react-icons/im";
import { RadioGroup } from "@headlessui/react";
import { getNfts } from "../../serivice/alchemyService";
import { getUserAddress } from "../../serivice/metamaskService";
import { LoadingCard } from "../loading";

interface IRadioGroupOption {
  data: string;
  tokenId: string;
  title: string;
  address: string;
  description?: string;
  imgUrl?: string;
}

function RadioGroupOptionItem({
  title,
  address,
  description,
  tokenId,
  imgUrl,
  data,
}: IRadioGroupOption) {
  return (
    <RadioGroup.Option
      value={data}
      className={({ active, checked }) =>
        `flex cursor-pointer rounded-lg px-4 py-3 shadow-md focus:outline-none
      ${active && "ring-2 ring-white ring-opacity-60"}
      ${checked ? "bg-sky-900 bg-opacity-75 text-white" : "bg-white"}`
      }
    >
      {({ active, checked }) => (
        <div className="flex w-full items-center justify-start">
          <div className="w-12 flex-none text-white">
            <ImCheckmark className={`h-6 w-6 ${!checked && "hidden"}`} />
          </div>
          <div className="grow flex">
            <img className="w-24 h-24" src={imgUrl} alt={title} />
            <div className="ml-2 flex items-center">
              <div className="text-sm">
                <RadioGroup.Label
                  className={`font-medium  ${
                    checked ? "text-white" : "text-gray-900"
                  }`}
                >
                  {title} #{tokenId}
                </RadioGroup.Label>
                <RadioGroup.Description
                  as="span"
                  className={`inline ${
                    checked ? "text-sky-100" : "text-gray-500"
                  }`}
                >
                  <div>{address}</div>
                  <div>{description}</div>
                </RadioGroup.Description>
              </div>
            </div>
          </div>
        </div>
      )}
    </RadioGroup.Option>
  );
}

interface INftList {
  selectedNft: any;
  onChange: any;
}

export function NFTList({ selectedNft, onChange }: INftList) {
  const [nfts, setNfts] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function init() {
      const user = await getUserAddress();
      console.log(user);
      const n = await getNfts(user);
      console.log(n);
      // console.log(n.ownedNfts);
      if (n && n.ownedNfts) {
        setNfts(n.ownedNfts);
        setIsLoading(false);
      }
      console.log("borrow init", n);
    }
    init();
  }, []);

  return (
    <div>
      {isLoading ? (
        <LoadingCard />
      ) : (
        <div className="w-full px-4 py-8">
          <div className="mx-auto w-full">
            <RadioGroup value={selectedNft} onChange={onChange}>
              <RadioGroup.Label className="sr-only">NFT List</RadioGroup.Label>
              <div className="space-y-2">
                {nfts.map((nft, i) => (
                  <RadioGroupOptionItem
                    key={i}
                    title={nft.title}
                    address={nft.contract.address}
                    description={nft.description}
                    tokenId={nft.tokenId}
                    imgUrl={nft.media[0]?.gateway}
                    data={nft}
                  />
                ))}
              </div>
            </RadioGroup>
          </div>
        </div>
      )}
    </div>
  );
}
