import React, { useEffect, useState } from "react";
import { RadioGroup } from "@headlessui/react";
import { ImCheckmark } from "react-icons/im";

interface IOffer {
  selected: any;
  onChange: any;
}

export interface TLoan {
  id: number;
  amount: number;
  period: number;
  interest: number;
  title?: string;
}

export function Offer({ selected, onChange }: IOffer) {
  const loans: TLoan[] = [
    { id: 1, amount: 0.0001, period: 3, interest: 2.86, title: "Basic" },
    { id: 2, amount: 0.0001, period: 5, interest: 2.55, title: "Best Choice" },
    { id: 3, amount: 0.0002, period: 7, interest: 2.2, title: "Long Period" },
  ];

  return (
    <div className="w-full px-4 py-8">
      <RadioGroup value={selected} by="id" onChange={onChange}>
        {/* <RadioGroup.Label>name</RadioGroup.Label> */}
        {loans.map((loan) => (
          <RadioGroup.Option
            className={({ active, checked }) =>
              `flex mb-1 cursor-pointer rounded-lg px-4 py-3 shadow-md focus:outline-none
      ${active && "ring-2 ring-white ring-opacity-60"}
      ${checked ? "bg-sky-900 bg-opacity-75 text-white" : "bg-white"}`
            }
            key={loan.id}
            value={loan}
          >
            {(checked) => (
              <div className="flex justify-start items-center w-full">
                <div className="w-12 flex-none text-white">
                  <ImCheckmark className={`h-6 w-6 ${!checked && "hidden"}`} />
                </div>
                <div className="grow">
                  <div className="mb-2 font-bold border-b border-dark-300">
                    {loan.title}
                  </div>
                  <div className="flex justify-between">
                    <div className="min-w-32">
                      <div className="text-sm opacity-50">Amount</div>
                      <div>{loan.amount} WETH</div>
                    </div>
                    <div className="min-w-32">
                      <div className="text-sm opacity-50">Period</div>
                      <div>{loan.period} days</div>
                    </div>
                    <div className="min-w-32">
                      <div className="text-sm opacity-50">Interest</div>
                      <div>{loan.interest}%</div>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </RadioGroup.Option>
        ))}
      </RadioGroup>
    </div>
  );
}
