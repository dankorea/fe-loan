import React from "react";
import { TLoan } from "./offer";

interface ITableItem {
  title: string;
  description: string | number | undefined;
}
function TableItem({ title, description }: ITableItem) {
  return (
    <div className="bg-gray-50 px-2 py-2 sm:grid sm:grid-cols-3 sm:gap-2 sm:px-2">
      <dt className="text-sm font-medium text-gray-500">{title}</dt>
      <dd className="mt-1 text-sm overflow-hidden overflow-ellipsis text-gray-900 sm:col-span-2 sm:mt-0">
        {description}
      </dd>
    </div>
  );
}

interface IOrderDetail {
  nft: any;
  loan: undefined | TLoan;
}
export function OrderDetail({ nft, loan }: IOrderDetail) {
  return (
    <div>
      <div className="flex justify-start items-center w-full">
        <img className="w-12 h-12 flex-shrink-0 border" src={nft?.media[0]?.gateway} alt="" />
        <div className="pl-2">
          <div className="font-bold">
            {nft?.title} #{nft?.tokenId}
          </div>
          <div className="text-xs overflow-hidden overflow-ellipsis text-gray-500">
            {nft?.contract.address}
          </div>
        </div>
      </div>
      <dl>
        <TableItem title="NFT Name" description={nft.title} />
        <TableItem title="NFT Address" description={nft.contract.address} />
        <TableItem title="Amount" description={loan?.amount} />
        <TableItem title="Period" description={loan?.period} />
        <TableItem title="Interest" description={loan?.interest} />
      </dl>
    </div>
  );
}
