import React from "react";

export function Footer() {
  return (
    <div className="mt-8 text-center">
      <div>Powered by dan.</div>
      <div className="font-thin text-sm">copyright 2022</div>
    </div>
  );
}
