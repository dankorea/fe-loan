import React, { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import { getUserAddress } from "../../serivice/metamaskService";

export function Header() {
  const [addr, setAddr] = useState("...");
  useEffect(() => {
    async function init() {
      setAddr(await getUserAddress());
    }
    init();
  }, []);

  return (
    <div className="flex justify-between items-center bg-white p-2">
      <div className="">Logo</div>
      <nav>
        <ul className="flex justify-center align-middle">
          <li className="mx-4">
            <NavLink
              to="/"
              className={({ isActive }) => (isActive ? "font-bold" : undefined)}
            >
              <div className="px-4 py-2 rounded-full hover:bg-gray-600 hover:text-white">
                Home
              </div>
            </NavLink>
          </li>
          <li className="mx-4">
            <NavLink
              to="/borrow"
              className={({ isActive }) => (isActive ? "font-bold" : undefined)}
            >
              <div className="px-4 py-2 rounded-full hover:bg-gray-600 hover:text-white">
                Borrow
              </div>
            </NavLink>
          </li>
          <li className="mx-4">
            <NavLink
              to="/loan"
              className={({ isActive }) => (isActive ? "font-bold" : undefined)}
            >
              <div className="px-4 py-2 rounded-full hover:bg-gray-600 hover:text-white">
                MyLoan
              </div>
            </NavLink>
          </li>
        </ul>
      </nav>

      <div className="font-thin text-sm">{addr}</div>
    </div>
  );
}
