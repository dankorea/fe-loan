import React from "react";
import { Header } from "./header";
import { Footer } from "./footer";
import { Outlet } from "react-router-dom";
import { hasMetamask } from "../../serivice/metamaskService";

export function Layout() {
  if (hasMetamask()) {
    return (
      <div>
        <Header />
        <Outlet />
        <Footer />
      </div>
    );
  } else {
    return (
      <div>
        <InstallMetamaskPage />
        <Footer />
      </div>
    );
  }
}

function InstallMetamaskPage() {
  return (
    <div className="py-10 text-center text-2xl font-bold">
      Please install Metamask!
    </div>
  );
}

