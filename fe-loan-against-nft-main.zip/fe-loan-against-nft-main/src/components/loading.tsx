import React from "react";
import { ImSpinner8 } from "react-icons/im";

export function LoadingCard() {
  return (
    <div className="flex justify-center items-center">
      <ImSpinner8 className="animate-spin" />
      <span className="ml-2 font-thin">Loading ...</span>
    </div>
  );
}
