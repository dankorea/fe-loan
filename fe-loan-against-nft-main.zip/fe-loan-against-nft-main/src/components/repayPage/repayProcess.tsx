import React, { useEffect, useState } from "react";
import { ImCheckmark, ImCheckmark2, ImSpinner8 } from "react-icons/im";
import {
  approve,
  allowance,
  getWethAddress,
} from "../../serivice/erc20Contract";
import {
  getLoanTokenAddress,
  getEscrowContractAddress,
  redeemLoan,
} from "../../serivice/escrowContract";
import { getUserAddress } from "../../serivice/metamaskService";

enum ApproveState {
  loading,
  approved,
  approving,
  notApproved,
}

interface IIconApprove {
  state: ApproveState;
}
function IconApprove({ state }: IIconApprove) {
  switch (state) {
    case ApproveState.loading:
      return (
        <span className="animate-spin">
          <ImSpinner8 />
        </span>
      );
    case ApproveState.approving:
      return (
        <span className="animate-spin">
          <ImSpinner8 />
        </span>
      );
    case ApproveState.approved:
      return (
        <span className="text-green-600">
          <ImCheckmark />
        </span>
      );
    case ApproveState.notApproved:
      return (
        <span className="text-gray-200">
          <ImCheckmark2 />
        </span>
      );
  }
}

interface IRepayProcess {
  loan: any;
  nextStage: any;
}
function RepayProcess({ loan, nextStage }: IRepayProcess) {
  const [isApproved, setIsApproved] = useState<ApproveState>(
    ApproveState.approving
  );
  const [isRepaying, setIsRepaying] = useState(false);

  useEffect(() => {
    async function initNFt() {
      const isApproved = await allowance(
        getWethAddress(),
        await getUserAddress(),
        getEscrowContractAddress()
      );
      if (isApproved) {
        setIsApproved(ApproveState.approved);
      } else {
        setIsApproved(ApproveState.notApproved);
      }
      console.log("token approve:", isApproved);
    }
    setIsApproved(ApproveState.loading);
    initNFt();
  }, [loan]);

  async function approveOnClicked() {
    console.log("start approve");
    try {
      setIsApproved(ApproveState.approving);
      const tx = await approve(
        getLoanTokenAddress(),
        getEscrowContractAddress()
      );
      await tx?.wait();
      setIsApproved(ApproveState.approved);
    } catch (e) {
      setIsApproved(ApproveState.notApproved);
      console.log("approve error", e);
    }
  }

  async function repayOnClick() {
    console.log("start borrow");
    try {
      setIsRepaying(true);
      if (loan?.nftAddress && loan?.nftId) {
        const tx = await redeemLoan(
          getLoanTokenAddress(),
          loan?.nftAddress,
          loan?.nftId
        );
        await tx.wait();
        setIsRepaying(false);
        nextStage();
      }
    } catch (e) {
      setIsRepaying(false);
      console.log("borrow error", e);
    }
  }

  return (
    <div>
      <div className="mt-8">
        <div className="underline-gray-700 flex justify-between items-center">
          <span>1.Approve WETH</span>
          <IconApprove state={isApproved} />
        </div>
        <div className="text-sm text-gray-400">
          We will ask you approval to access your WETH. This is a one-time only
          operation.
        </div>
        <div className={isApproved === ApproveState.approved ? "hidden" : ""}>
          <button
            className="inline-flex justify-center items-center rounded-md border border-transparent bg-green-600
             px-4 py-2 text-sm font-medium text-green-100 hover:bg-blue-200 focus:outline-none focus-visible:ring-2
              focus-visible:ring-blue-500 focus-visible:ring-offset-2 disabled:bg-gray-400 disabled:text-gray-700"
            disabled={
              isApproved === ApproveState.loading ||
              isApproved === ApproveState.approving
            }
            onClick={approveOnClicked}
          >
            {isApproved === ApproveState.approving && (
              <span className="animate-spin mr-2">
                <ImSpinner8 />
              </span>
            )}
            <span>Approve</span>
          </button>
        </div>
      </div>
      <div className="mt-8">
        <div className="underline-gray-700 flex justify-between items-center">
          <span>2.Confirm Repaying</span>
        </div>
        <div className="text-sm text-gray-400">Confirm and transfer</div>
        <div className={isApproved !== ApproveState.approved ? "hidden" : ""}>
          <button
            className="inline-flex justify-center items-center rounded-md border border-transparent bg-green-600
             px-4 py-2 text-sm font-medium text-green-100 hover:bg-blue-200 focus:outline-none focus-visible:ring-2
              focus-visible:ring-blue-500 focus-visible:ring-offset-2 disabled:bg-gray-400 disabled:text-gray-700"
            disabled={isRepaying}
            onClick={repayOnClick}
          >
            {isRepaying && (
              <span className="animate-spin mr-2">
                <ImSpinner8 />
              </span>
            )}
            <span>Repay</span>
          </button>
        </div>
      </div>
    </div>
  );
}

export { RepayProcess };
