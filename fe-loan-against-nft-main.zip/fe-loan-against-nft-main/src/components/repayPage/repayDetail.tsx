import React from "react";
import { utils } from "ethers";

interface ITableItem {
  title: string;
  description: string | number | undefined;
}
function TableItem({ title, description }: ITableItem) {
  return (
    <div className="bg-gray-50 px-2 py-2 sm:grid sm:grid-cols-3 sm:gap-2 sm:px-2">
      <dt className="text-sm font-medium text-gray-500">{title}</dt>
      <dd className="mt-1 text-sm overflow-hidden overflow-ellipsis text-gray-900 sm:col-span-2 sm:mt-0">
        {description}
      </dd>
    </div>
  );
}

interface IRepayDetail {
  loan: any;
  metadata: any;
}
export function RepayDetail({ loan, metadata }: IRepayDetail) {
  console.log("repay detail loan:", loan);
  console.log("repay detail meta:", metadata);
  return (
    <div>
      <div className="flex justify-start items-center w-full">
        <img
          className="w-12 h-12 flex-shrink-0 border"
          src={metadata?.media[0]?.gateway}
          alt="img"
        />
        <div className="pl-2">
          <div className="font-bold">
            {metadata?.title} #{metadata?.tokenId}
          </div>
          <div className="text-xs overflow-hidden overflow-ellipsis text-gray-500">
            {metadata?.contract.address}
          </div>
        </div>
      </div>
      <dl>
        <TableItem title="NFT Name" description={metadata.title} />
        <TableItem
          title="NFT Address"
          description={metadata.contract.address}
        />
        <TableItem title="NFT ID" description={metadata.tokenId} />
        <TableItem title="NFT Description" description={metadata.description} />
        <TableItem
          title="Repay Amount"
          description={utils.formatEther(loan?.repayAmount) + " WETH"}
        />
        <TableItem
          title="Expire"
          description={new Date(
            parseInt(loan?.expireTime) * 1000
          ).toLocaleString()}
        />
      </dl>
    </div>
  );
}
