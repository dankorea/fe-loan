import React, { useEffect, useState } from "react";
import { ImCheckmark } from "react-icons/im";
import { RadioGroup } from "@headlessui/react";
import { getNftMetadataBatch } from "../../serivice/alchemyService";
import { getUserAddress } from "../../serivice/metamaskService";
import { LoadingCard } from "../loading";
import { getLoanList } from "../../serivice/escrowContract";
import { utils } from "ethers";

interface IRadioGroupOption {
  data: any;
  title?: string;
  tokenId: string;
  address: string;
  repayAmount: string;
  expireTime: string;
  imgUrl?: string;
}

function RadioGroupOptionItem({
  tokenId,
  address,
  title,
  repayAmount,
  imgUrl,
  expireTime,
  data,
}: IRadioGroupOption) {
  return (
    <RadioGroup.Option
      value={data}
      className={({ active, checked }) =>
        `flex cursor-pointer rounded-lg px-5 py-4 shadow-md focus:outline-none
      ${active && "ring-2 ring-white ring-opacity-60"}
      ${checked ? "bg-sky-900 bg-opacity-75 text-white" : "bg-white"}`
      }
    >
      {({ active, checked }) => (
        <>
          <div className="flex w-full items-center justify-start">
            <div className={`mr-2 shrink-0 text-white ${!checked && "hidden"}`}>
              <ImCheckmark className="h-6 w-6" />
            </div>
            <img className="w-16 h-16 border" src={imgUrl} alt="img" />
            <div className="ml-2 flex items-center flex-auto">
              <div className="text-sm">
                <RadioGroup.Label
                  className={`text-lg font-bold ${
                    checked ? "text-white" : "text-gray-900"
                  }`}
                >
                  {title} #{tokenId}
                </RadioGroup.Label>
                <RadioGroup.Description
                  as="span"
                  className={`inline ${
                    checked ? "text-sky-100" : "text-gray-900"
                  }`}
                >
                  <div className="opacity-50">{address}</div>
                  <div>
                    <span className="text-lg">
                      {utils.formatUnits(repayAmount)}
                    </span>
                    <span className="ml-1 opacity-60">WETH</span>
                  </div>
                </RadioGroup.Description>
              </div>
            </div>
            <div className="ml-2 text-right">
              <div className="opacity-60">Expire</div>
              <div>
                {new Date(parseInt(expireTime) * 1000).toLocaleString()}
              </div>
            </div>
          </div>
        </>
      )}
    </RadioGroup.Option>
  );
}

interface ILoanList {
  selectedLoan: any;
  onChange: any;
}

export function LoanList({ selectedLoan, onChange }: ILoanList) {
  const [loans, setLoans] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    async function init() {
      const user = await getUserAddress();
      console.log(user);
      const n = await getLoanList(user);
      console.log("loanlist", n);
      // console.log(n.ownedNfts);
      if (n) {
        if (n.length > 0) {
          const batch = n.map((item) => {
            return { contractAddress: item?.nftAddress, tokenId: item?.nftId };
          });
          const nftMetadata = await getNftMetadataBatch(batch);
          console.log("metadata batch", nftMetadata);
          const fullLoanList = n.map((value, i) => {
            const tmp: any = value;
            if (nftMetadata && nftMetadata[i]) {
              tmp["imgUrl"] = nftMetadata[i]?.media[0]?.gateway;
              tmp["metadata"] = nftMetadata[i];
              return tmp;
            }
            return value;
          });
          setLoans(fullLoanList);
        }
        setIsLoading(false);
        console.log("loans init", n);
      }
    }
    init();
  }, []);

  return (
    <div>
      {isLoading ? (
        <LoadingCard />
      ) : (
        <div className="w-full px-4 py-8">
          <div className="mx-auto w-full">
            <RadioGroup value={selectedLoan} onChange={onChange}>
              <RadioGroup.Label className="sr-only">Loan List</RadioGroup.Label>
              <div className="space-y-2">
                {loans.map((loan, i) => (
                  <RadioGroupOptionItem
                    key={i}
                    address={loan.nftAddress}
                    title={loan?.metadata?.title}
                    tokenId={loan.nftId}
                    repayAmount={loan.repayAmount}
                    expireTime={loan.expireTime}
                    imgUrl={loan?.imgUrl}
                    data={loan}
                  />
                ))}
              </div>
            </RadioGroup>
          </div>
        </div>
      )}
    </div>
  );
}
