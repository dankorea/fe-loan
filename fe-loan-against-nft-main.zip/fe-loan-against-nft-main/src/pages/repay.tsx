import React, { useState } from "react";
import RepayModal from "../components/repayPage/repayModal";
import { LoanList } from "../components/repayPage/loanList";

export function Repay() {
  const [selectedLoan, setSelectedLoan] = useState<any>(undefined);
  const [isRepayModalOpen, setIsRepayModalOpen] = useState<boolean>(false);

  return (
    <div className="mx-4 mx-auto max-w-12xl">
      {/* modal */}
      <RepayModal
        isOpen={isRepayModalOpen}
        setIsOpen={setIsRepayModalOpen}
        loan={selectedLoan}
      />
      {/* step1 */}
      <div className="mt-4">
        <div className="text-lg font-bold">Please select a loan</div>
        <div className="my-2 text-sm font-light text-gray-400">
          Choose the loan that you want to repay.
        </div>
        <div className="w-full">
          <LoanList selectedLoan={selectedLoan} onChange={setSelectedLoan} />
        </div>
      </div>
      {/* comfirm */}
      <div className="max-w-xl px-4 py-8">
        <button
          className="mt-6 w-full text-white truncate disabled:opacity-40 disabled:cursor-not-allowed focus:outline-none focus-visible:outline-2 focus-visible:outline-offset-2 hover:enabled:bg-primary-1-600 ts-button-2 h-10 px-4 rounded-lg bg-blue-500"
          disabled={selectedLoan === undefined}
          onClick={() => setIsRepayModalOpen(!isRepayModalOpen)}
        >
          Repay
        </button>
      </div>
    </div>
  );
}
