import React, { useState } from "react";
import BorrowModal from "../components/borrowPage/borrowModal";
import { NFTList } from "../components/borrowPage/NFTList";
import { Offer } from "../components/borrowPage/offer";

export function Borrow() {
  const [selectedNft, setSelectedNft] = useState<any>(undefined);
  const [selectedOffer, setSelectedOffer] = useState<any>(undefined);
  const [isBorrowModalOpen, setIsBorrowModalOpen] = useState<boolean>(false);

  return (
    <div className="mx-4 mx-auto max-w-12xl">
      {/* modal */}
      <BorrowModal
        isOpen={isBorrowModalOpen}
        setIsOpen={setIsBorrowModalOpen}
        nft={selectedNft}
        loan={selectedOffer}
      />
      {/* step1 */}
      <div className="mt-4">
        <div className="text-lg font-bold">Step 1: select an NFT</div>
        <div className="my-2 text-sm font-light text-gray-400">
          Choose the NFT item that you want to use as collateral to establish a
          loan.
        </div>
        <div className="w-full">
          <NFTList selectedNft={selectedNft} onChange={setSelectedNft} />
        </div>
      </div>
      {/* step2 */}
      <div className="mt-4">
        <div className="text-lg font-bold">Step 2: Select a loan offer</div>
        <div className="my-2 text-sm font-light text-gray-400">
          Pick a loan offer that matches your need. Read the figures carefully
          before accept any offers.
        </div>
        <div className="w-full">
          <Offer selected={selectedOffer} onChange={setSelectedOffer} />
        </div>
      </div>
      {/* comfirm */}
      <div className="max-w-xl px-4 py-8">
        <button
          className="mt-6 w-full text-white truncate disabled:opacity-40 disabled:cursor-not-allowed focus:outline-none focus-visible:outline-2 focus-visible:outline-offset-2 hover:enabled:bg-primary-1-600 ts-button-2 h-10 px-4 rounded-lg bg-blue-500"
          disabled={selectedNft === undefined || selectedOffer === undefined}
          onClick={() => setIsBorrowModalOpen(!isBorrowModalOpen)}
        >
          Borrow
        </button>
      </div>
    </div>
  );
}
