import { ethers } from "ethers";
const { ethereum }: any = window;

let mySigner: undefined | ethers.providers.JsonRpcSigner = undefined;
let myProvider: undefined | ethers.providers.Web3Provider = undefined;

function hasMetamask() {
  return typeof ethereum !== "undefined";
}

async function getProvider() {
  try {
    if (!myProvider) {
      myProvider = new ethers.providers.Web3Provider(ethereum);
    }
    return myProvider;
  } catch (e) {
    return undefined;
  }
}

async function getChainId() {
  try {
    if (hasMetamask()) {
      const provider = await getProvider();
      if (provider) {
        return provider.network.chainId;
      }
      return undefined;
    }
  } catch (e) {
    return undefined;
  }
}

async function getSigner() {
  try {
    if (hasMetamask()) {
      if (!mySigner) {
        const provider = await getProvider();
        if (provider) {
          await provider.send("eth_requestAccounts", []);
          mySigner = provider.getSigner();
          console.log("Account:", await mySigner.getAddress());
        }
      }
      return mySigner;
    }
  } catch (e) {
    return undefined;
  }
}

async function getUserAddress() {
  const s = await getSigner();
  if (s) {
    const addr = await s.getAddress();
    return addr;
  }
  return "";
}

async function getUserBalance() {
  const s = await getSigner();
  if (s) {
    return await s.getBalance();
  }
  return 0;
}

export {
  ethereum,
  hasMetamask,
  getSigner,
  getUserAddress,
  getUserBalance,
  getChainId,
  getProvider,
};
