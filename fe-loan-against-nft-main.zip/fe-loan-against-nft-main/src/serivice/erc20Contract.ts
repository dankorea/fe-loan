import TokenJson from "../contracts/DappToken.json";
import { getChainId, getProvider, getSigner } from "./metamaskService";
import { ethers, constants, utils, BigNumber } from "ethers";

const tokenContracts: { [propName: string]: ethers.Contract } = {};

const WethAddress = "0xB4FBF271143F4FBf7B91A5ded31805e42b2208d6";

function getWethAddress() {
  return WethAddress;
}

async function getTokenContract(address: string) {
  try {
    if (!tokenContracts[address]) {
      const chainId = await getChainId();
      if (chainId !== undefined) {
        const provider = await getProvider();
        tokenContracts[address] = new ethers.Contract(
          address,
          TokenJson.abi,
          provider
        );
      }
    }
    return tokenContracts[address];
  } catch (e) {
    return undefined;
  }
}

async function approve(tokenAddress: string, escrowAddress: string) {
  const contract = await getTokenContract(tokenAddress);
  const signer = await getSigner();
  if (signer) {
    const signedContract = contract?.connect(signer);
    const tx = await signedContract?.approve(
      escrowAddress,
      constants.WeiPerEther.mul(BigNumber.from(10)).toString()
    );
    console.log("approve tx", tx);
    return tx;
  }
}

async function allowance(
  tokenAddress: string,
  owner: string,
  spender: string
): Promise<boolean> {
  try {
    const contract = await getTokenContract(tokenAddress);
    const allowance = await contract?.allowance(owner, spender);
    console.log(utils.formatEther(allowance));
    return utils.parseEther("5").lte(allowance);
  } catch (e) {
    console.log("get allowance error", e);
  }
  return false;
}

export { getTokenContract, approve, allowance, getWethAddress };
