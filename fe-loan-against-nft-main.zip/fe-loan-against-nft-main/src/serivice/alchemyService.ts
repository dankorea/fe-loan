import { Alchemy, Network } from "alchemy-sdk";
import { getWhiteList } from "./escrowContract";

let myAlchemy: undefined | Alchemy = undefined;
async function getAlchemy() {
  if (!myAlchemy) {
    const settings = {
      apiKey: process.env.REACT_APP_ALCHEMY_API_KEY,
      network: Network.ETH_GOERLI, // Replace with your network.
    };
    myAlchemy = new Alchemy(settings);
  }
  return myAlchemy;
}

async function getNfts(ownerAddr: string) {
  const whiteListContractAddr = await getWhiteList();
  console.log("white list", whiteListContractAddr);
  try {
    const alchemy = await getAlchemy();
    if (alchemy) {
      const nfts = await alchemy.nft.getNftsForOwner(ownerAddr, {
        omitMetadata: false,
        contractAddresses: whiteListContractAddr,
      });
      return nfts;
    }
  } catch (e) {
    console.log("get nft error", e);
  }
}

interface INftBatchItem {
  contractAddress: string;
  tokenId: string;
}

async function getNftMetadataBatch(NftBatch: INftBatchItem[]) {
  console.log("getMetaData", NftBatch);
  try {
    const alchemy = await getAlchemy();
    if (alchemy) {
      const nfts = await alchemy.nft.getNftMetadataBatch(NftBatch);
      return nfts;
    }
  } catch (e) {
    console.log("get nft error", e);
  }
}

export { getNfts, getNftMetadataBatch };
