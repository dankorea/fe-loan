import escrowJson from "../contracts/Escrow.json";
import network from "../conf/map.json";
import { getChainId, getProvider, getSigner } from "./metamaskService";
import { BigNumber, ethers, utils } from "ethers";
import brownie_config from "../conf/brownie-config.json";

function getLoanTokenAddress() {
  // const chainId = await getChainId();
  // const networkName = helper_config[chainId];
  // const tokenAddress = brownie_config["networks"][networkName]["loan_token"];
  // return tokenAddress;
  //// const tokenJson = await inputJsonFile("../contracts/MockLoanToken.json");
  //// const tokenContract = new web3.eth.Contract(tokenJson.abi, tokenAddress);
  return brownie_config["networks"]["goerli"]["loan_token"];
}

function getEscrowContractAddress() {
  return network["5"]["Escrow"][0];
}

let escrowContractHandler: undefined | ethers.Contract = undefined;
async function getEscrowContract() {
  try {
    if (!escrowContractHandler) {
      const chainId = await getChainId();
      if (chainId !== undefined) {
        const escrowAddress = getEscrowContractAddress();
        const provider = await getProvider();
        escrowContractHandler = new ethers.Contract(
          escrowAddress,
          escrowJson.abi,
          provider
        );
      }
    }
    return escrowContractHandler;
  } catch (e) {
    return undefined;
  }
}

async function getWhiteList() {
  const escrow = await getEscrowContract();
  if (escrow) {
    const total = await escrow.numOfAllowedNfts();
    const l: Array<string> = [];
    for (let i = 0; i < total; i++) {
      const allowedNftAddr: string = await escrow.allowedNfts(i);
      l.push(allowedNftAddr);
    }
    return l;
  }
  return [];
}

interface ILoan {
  //title?: string;
  nftAddress: string;
  nftId: string;
  repayAmount: string;
  expireTime: string;
}

async function getLoanList(borrowerAddress: string) {
  const loanList: ILoan[] = [];
  const escrow = await getEscrowContract();

  if (escrow) {
    const numOfNftStakedBG = await escrow.numOfNftStaked(borrowerAddress);
    const numOfNftStaked = numOfNftStakedBG.toNumber();
    for (let i = 0; i < numOfNftStaked; i++) {
      const nft_address = await escrow.stakedNftAddress(borrowerAddress, i);
      const nft_id = (await escrow.stakedNftId(borrowerAddress, i)).toString();
      const repay_amount = (
        await escrow.nftLoanRepayAmount(nft_address, nft_id)
      ).toString();
      const expire_time = (
        await escrow.nftLoanExpireTime(nft_address, nft_id)
      ).toString();
      const loan: ILoan = {
        nftAddress: nft_address,
        nftId: nft_id,
        repayAmount: repay_amount,
        expireTime: expire_time,
      };
      console.log(loan);
      loanList.push(loan);
    }
  }
  // return loan
  return loanList;
}

async function requestLoan(
  tokenAddress: string,
  nftAddress: string,
  nftId: string
) {
  const escrow = await getEscrowContract();
  if (escrow) {
    const signer = await getSigner();
    if (signer) {
      const signedContract = escrow.connect(signer);
      const tx = signedContract.requestLoan(tokenAddress, nftAddress, nftId);
      return tx;
    }
  }
}

async function setOffers(
  nftAddress: string,
  nftId: string,
  loanAmount: number,
  loanPeriod: number,
  loanInterest: number
) {
  const escrow = await getEscrowContract();
  if (escrow) {
    const signer = await getSigner();
    if (signer) {
      const signedContract = escrow.connect(signer);
      const loan_amount = utils.parseEther(loanAmount.toString());
      const loan_interest = BigNumber.from((loanInterest * 100).toFixed(0));
      const tx = signedContract.setOffers(
        nftAddress,
        nftId,
        loan_amount.toString(),
        BigNumber.from(loanPeriod.toFixed(0)).toString(),
        loan_interest.toString()
      );
      // const tx = signedContract.setOffers(nftAddress, nftId, loanAmount, loanPeriod, loanInterest);
      return tx;
    }
  }
}

async function getOffers(nftAddress: string, nftId: string) {
  const escrow = await getEscrowContract();
  if (escrow) {
    const signer = await getSigner();
    if (signer) {
      const signedContract = escrow.connect(signer);
      const tx = signedContract.getOffers(nftAddress, nftId);
      return tx;
    }
  }
}

async function redeemLoan(
  tokenAddress: string,
  nftAddress: string,
  tokenId: string
) {
  const escrow = await getEscrowContract();
  if (escrow) {
    const signer = await getSigner();
    if (signer) {
      const signedContract = escrow.connect(signer);
      const tx = signedContract.redeemLoan(tokenAddress, nftAddress, tokenId);
      return tx;
    }
  }
  return undefined;
}

export {
  getWhiteList,
  getEscrowContractAddress,
  requestLoan,
  getLoanTokenAddress,
  setOffers,
  getOffers,
  getLoanList,
  redeemLoan,
};
