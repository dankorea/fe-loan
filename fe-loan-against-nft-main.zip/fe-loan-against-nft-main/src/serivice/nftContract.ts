import NftJson from "../contracts/SimpleNFT.json";
import { getChainId, getProvider, getSigner } from "./metamaskService";
import { ethers } from "ethers";

const nftContracts: { [propName: string]: ethers.Contract } = {};
async function getNftContract(address: string) {
  try {
    if (!nftContracts[address]) {
      const chainId = await getChainId();
      if (chainId !== undefined) {
        const provider = await getProvider();
        nftContracts[address] = new ethers.Contract(
          address,
          NftJson.abi,
          provider
        );
      }
    }
    return nftContracts[address];
  } catch (e) {
    return undefined;
  }
}

async function approve(
  nftAddress: string,
  escrowAddress: string,
  nftId: number
) {
  const contract = await getNftContract(nftAddress);
  const signer = await getSigner();
  if (signer) {
    const signedContract = contract?.connect(signer);
    const tx = await signedContract?.approve(escrowAddress, nftId);
    console.log("approve tx", tx);
    return tx;
  }
}

async function getApprovedFor(
  nftAddress: string,
  tokenId: number,
  newOwner: string
) {
  try {
    const contract = await getNftContract(nftAddress);
    const owner: string = await contract?.getApproved(tokenId);
    return owner.toLowerCase() === newOwner.toLowerCase();
  } catch (e) {
    console.log("get approved error", e);
  }
}
export { getNftContract, approve, getApprovedFor };
