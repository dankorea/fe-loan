# Getting Started with Create React App

This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

## Available Scripts

In the project directory, you can run:

### `pnpm start`

Runs the app in the development mode.\
Open [http://localhost:3000](http://localhost:3000) to view it in the browser.

The page will reload if you make edits.\
You will also see any lint errors in the console.

### `pnpm test`

Launches the test runner in the interactive watch mode.\
See the section about [running tests](https://facebook.github.io/create-react-app/docs/running-tests) for more information.

### `pnpm run build`

Builds the app for production to the `build` folder.\
It correctly bundles React in production mode and optimizes the build for the best performance.

The build is minified and the filenames include the hashes.\
Your app is ready to be deployed!

See the section about [deployment](https://facebook.github.io/create-react-app/docs/deployment) for more information.

### `pnpm run eject`

**Note: this is a one-way operation. Once you `eject`, you can’t go back!**

If you aren’t satisfied with the build tool and configuration choices, you can `eject` at any time. This command will remove the single build dependency from your project.

Instead, it will copy all the configuration files and the transitive dependencies (webpack, Babel, ESLint, etc) right into your project so you have full control over them. All of the commands except `eject` will still work, but they will point to the copied scripts so you can tweak them. At this point you’re on your own.

You don’t have to ever use `eject`. The curated feature set is suitable for small and middle deployments, and you shouldn’t feel obligated to use this feature. However we understand that this tool wouldn’t be useful if you couldn’t customize it when you are ready for it.

## Learn More

You can learn more in the [Create React App documentation](https://facebook.github.io/create-react-app/docs/getting-started).

To learn React, check out the [React documentation](https://reactjs.org/).

# 当前工程使用说明

## 安装依赖

使用指令 `pnpm i`

## 需要修改的配置

`.env 文件`，参考`.env.example`修改为自己的 alchemy 生成的api-key。 并将文件命名为 `.env`

## 调试

使用指令 `pnpm dev`

## 特殊链接目录结构

`src` 中有两个特殊文件目录，需要使用软连接，连接到之前的 loanAgainstNFT 对应目录

```
lrwxr-xr-x  29 qxc 29 11 21:42 conf -> ../../loanAgainstNFT/web/conf
lrwxr-xr-x  36 qxc 29 11 21:41 contracts -> ../../loanAgainstNFT/build/contracts
```

参考如上所示,所以需要将两个工程放在同级目录中，方便对齐使用。